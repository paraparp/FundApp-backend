package com.paraparp.gestorfondos.batch.listener;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemWriteListener;

import com.paraparp.gestorfondos.model.entity.Symbol;

public class PriceWriterListener implements ItemWriteListener<Symbol> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PriceWriterListener.class);

    @Override
    public void beforeWrite(List<? extends Symbol> list) {
        LOGGER.info("beforeWrite");
    }


    @Override
    public void afterWrite(List<? extends Symbol> list) {
        for (Symbol symbol : list) {
            LOGGER.info("afterWrite :" + symbol.toString());
        }
    }

    @Override
    public void onWriteError(Exception e, List<? extends Symbol> list) {
        LOGGER.info("onWriteError");
    }
}