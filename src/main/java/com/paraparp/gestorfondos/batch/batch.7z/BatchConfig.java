package com.paraparp.gestorfondos.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.step.tasklet.TaskletStep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.paraparp.gestorfondos.batch.job.PriceProcessor;
import com.paraparp.gestorfondos.batch.job.PriceReader;
import com.paraparp.gestorfondos.batch.job.PriceWriter;
import com.paraparp.gestorfondos.batch.listener.PriceJobExecutionListener;
import com.paraparp.gestorfondos.batch.listener.PriceProcessListener;
import com.paraparp.gestorfondos.batch.listener.PriceReaderListener;
import com.paraparp.gestorfondos.batch.listener.PriceWriterListener;
import com.paraparp.gestorfondos.model.entity.Symbol;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Bean
    public PriceReader reader() {
        return new PriceReader();
    }

    @Bean
    public PriceProcessor processor() {
        return new PriceProcessor();
    }

    @Bean
    public PriceWriter writer() {
        return new PriceWriter();
    }

    @Bean
    public PriceJobExecutionListener jobExecutionListener() {
        return new PriceJobExecutionListener();
    }

    @Bean
    public PriceReaderListener readerListener() {
        return new PriceReaderListener();
    }

    @Bean
    public PriceProcessListener creditCardItemProcessListener() {
        return new PriceProcessListener();
    }

    @Bean
    public PriceWriterListener writerListener() {
        return new PriceWriterListener();
    }

    @Bean
    public Job job(Step step, PriceJobExecutionListener jobExecutionListener) {
        Job job = jobBuilderFactory.get("job1")
                .listener(jobExecutionListener)
                .flow(step)
                .end()
                .build();
        return job;
    }

    @Bean
    public Step step(PriceReader reader,
                     PriceWriter writer,
                     PriceProcessor processor,
                     PriceReaderListener readerListener,
                     PriceProcessListener creditCardItemProcessListener,
                     PriceWriterListener writerListener) {

        TaskletStep step = stepBuilderFactory.get("step1")
                .<Symbol, Symbol>chunk(100)
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .listener(readerListener)
                .listener(creditCardItemProcessListener)
                .listener(writerListener)
                .build();
        return step;
    }

}