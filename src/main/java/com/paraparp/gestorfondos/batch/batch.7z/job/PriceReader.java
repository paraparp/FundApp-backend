package com.paraparp.gestorfondos.batch.job;

import java.util.Iterator;

import javax.batch.runtime.StepExecution;

import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;

import com.paraparp.gestorfondos.model.entity.Symbol;
import com.paraparp.gestorfondos.repository.ISymbolRepository;

public class PriceReader implements ItemReader<Symbol> {

	@Autowired
	public ISymbolRepository symbolRepo;

	@Autowired
	private ISymbolRepository respository;

	private Iterator<Symbol> iterator;

	@BeforeStep
	public void before(StepExecution stepExecution) {
		iterator = respository.findAll().iterator();
	}

	@Override
	public Symbol read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		if (iterator != null && iterator.hasNext()) {
			return iterator.next();
		} else {
			return null;
		}
	}
}