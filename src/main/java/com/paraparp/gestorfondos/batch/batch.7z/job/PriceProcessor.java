package com.paraparp.gestorfondos.batch.job;

import java.util.Date;

import org.springframework.batch.item.ItemProcessor;

import com.paraparp.gestorfondos.model.entity.Symbol;
import com.paraparp.gestorfondos.util.ExtraData;
import com.paraparp.gestorfondos.util.Util;

public class PriceProcessor implements ItemProcessor<Symbol, Symbol> {

	@Override
	public Symbol process(Symbol symbol) throws Exception {

		ExtraData bd = Util.getFTData(symbol);

		if (bd != null)
		{
			symbol.setLastPrice(bd.getLastPrice());
//		symbol.setMaxPrice(bd.getMaxPrice());
//		symbol.seMinPrice(bd.getMinPrice());
//		symbol.setUpdatedAt(bd.getUpdatedAt());
			symbol.setUpdated(new Date());
		}
		return symbol;
	}

}