package com.paraparp.gestorfondos.batch.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemReadListener;

import com.paraparp.gestorfondos.model.entity.Symbol;

public class PriceReaderListener implements ItemReadListener<Symbol> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PriceReaderListener.class);

    @Override
    public void beforeRead() {
        LOGGER.info("beforeRead");
    }

    @Override
    public void afterRead(Symbol symbol) {
        LOGGER.info("afterRead: " + symbol.toString());
    }

    @Override
    public void onReadError(Exception e) {
        LOGGER.info("onReadError");
    }
}