package com.paraparp.gestorfondos.batch.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemProcessListener;

import com.paraparp.gestorfondos.model.entity.Symbol;

public class PriceProcessListener implements ItemProcessListener<Symbol, Symbol> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PriceProcessListener.class);

    @Override
    public void beforeProcess(Symbol creditCard) {
        LOGGER.info("beforeProcess");
    }

    @Override
    public void afterProcess(Symbol symbol, Symbol updatedSymbol) {
        LOGGER.info("afterProcess: " + symbol + " ---> " + updatedSymbol);
    }

    @Override
    public void onProcessError(Symbol symbol, Exception e) {
        LOGGER.info("onProcessError");
    }
}