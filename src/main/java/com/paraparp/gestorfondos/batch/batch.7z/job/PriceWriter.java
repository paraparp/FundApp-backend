package com.paraparp.gestorfondos.batch.job;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.paraparp.gestorfondos.model.entity.Symbol;
import com.paraparp.gestorfondos.repository.ISymbolRepository;

public class PriceWriter implements ItemWriter<Symbol> {

	@Autowired
	private ISymbolRepository repo;

	@Override
	public void write(List<? extends Symbol> symbols) throws Exception {

		repo.saveAll(symbols);
	}
}
